# Dictionary of letters mapped to Lahore landmarks
landmark_choices = {
    'a': 'Badshahi Mosque',
    'b': 'Lahore Fort',
    'c': 'Minar-e-Pakistan',
    'd': 'Liberty Market',
    'e': 'Gaddafi Stadium',
    'f': 'Shalimar Gardens',
    'g': 'Anarkali Bazaar',
    'h': 'Lahore Museum',
    'i': 'Data Darbar',
    'j': 'Mall Road',
    'k': 'Punjab University',
    'l': 'Model Town Park',
    'm': 'Ichra Bazaar',
    'n': 'Youhanabad Church',
    'o': 'Wapda Town'
    # Add more as needed
}
